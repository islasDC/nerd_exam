@extends('layout')

  

@section('content')
<div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Tagboard') }}</div>
                <div class="card-body">
                    @if ($message = Session::get('success'))
                    <div class="alert alert-success">
                        <p>{{ $message }}</p>
                    </div>
                    @endif
                    <table class="table table-bordered">
                        <tr>
                            <th>#</th>
                            <th>Room Number</th>
                            <th>Room Description</th>
                            <!-- <th>Room Status</th> -->
                            <th width="280px">Action</th>
                        </tr>
                        @foreach ($rooms as $room)
                        <tr>
                            <td>{{ $room->id }}</td>
                            <td>{{ $room->room_number }}</td>
                            <td>{{ $room->room_description }}</td>
                            <!-- <td>{{ $room->room_status_id }}</td> -->
                            <td>
                                                                                    
                            <a class="btn btn-primary" href="{{ route('tagboards.edit', $room->id) }}">View</a>
                                                        
                            </td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
{!! $rooms->links() !!}
@endsection