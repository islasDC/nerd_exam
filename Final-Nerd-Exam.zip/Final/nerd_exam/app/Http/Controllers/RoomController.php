<?php
namespace App\Http\Controllers;
use App\Models\Room;
use Illuminate\Http\Request;
class RoomController extends Controller
{
    
    public function index()
    {
        $data['rooms'] = Room::orderBy('id','desc')->paginate(5);
        return view('rooms.index', $data);
    }
        
    public function create()
    {
        return view('rooms.create');
    }

    public function store(Request $request)
    {
        $room = new Room;
        $room->room_number = $request->room_number;
        $room->room_description = $request->room_description;
        $room->room_status_id = $request->room_status_id;
        $room->save();
        return redirect()->route('rooms.index')
            ->with('success','Room has been created successfully.');
    }

    public function show(Room $room)
    {
        return view('rooms.show',compact('room'));
    } 

    public function edit(Room $room)
    {
        return view('rooms.edit',compact('room'));
    }

    public function update(Request $request, $id)
    {

        $room = Room::find($id);
        $room->room_number = $request->room_number;
        $room->room_description = $request->room_description;
        $room->room_status_id = $request->room_status_id;
        $room->save();
        return redirect()->route('rooms.index')
            ->with('success','Room Has Been updated successfully');
    }

    public function destroy(Room $room)
    {
        $room->delete();
        return redirect()->route('rooms.index')
           ->with('success','Room has been deleted successfully');
    }
}