<?php
namespace App\Http\Controllers;
use App\Models\Room;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class TagboardController extends Controller
{
    
    public function index()
    {
         $data['rooms'] = Room::orderBy('id','desc')->paginate(5);
        
        return view('tagboards.index', $data);
    }
        
    public function create()
    {
        return view('tagboards.create');
    }

    public function show(Room $room)
    {
        return view('tagboards.show',compact('room'));
    } 

    public function edit($id)
    {
        // $room = Room::find($id);
        $room = DB::table('rooms')->where('rooms.id', $id)
        ->join('room_status','room_status.id','=','rooms.room_status_id')
        ->select('rooms.*','room_status.name as status','room_status.color')
        ->first();
        return view('tagboards.edit',compact('room'));
    }
}