

  

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Tagboard')); ?></div>
                <div class="card-body">
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                    <?php endif; ?>
                    <table class="table table-bordered">
                        <tr>
                            <th>#</th>
                            <th>Room Number</th>
                            <th>Room Description</th>
                            <!-- <th>Room Status</th> -->
                            <th width="280px">Action</th>
                        </tr>
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($room->id); ?></td>
                            <td><?php echo e($room->room_number); ?></td>
                            <td><?php echo e($room->room_description); ?></td>
                            <!-- <td><?php echo e($room->room_status_id); ?></td> -->
                            <td>
                                                                                    
                            <a class="btn btn-primary" href="<?php echo e(route('tagboards.edit', $room->id)); ?>">View</a>
                                                        
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $rooms->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Downloads\New folder\teset\example-app\resources\views/tagboards/index.blade.php ENDPATH**/ ?>