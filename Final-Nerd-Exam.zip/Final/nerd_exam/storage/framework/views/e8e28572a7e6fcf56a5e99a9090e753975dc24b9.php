<html>
    <head>
        <?php if($title): ?>
                <title><?php echo e($title); ?></title>
        <?php else: ?>
                <title>Example Laravel App</title>
        <?php endif; ?>
    </head>
    <body>
        <div><a href="/home">Home</a> | <a href="/about">About</a>
        <hr/>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html><?php /**PATH D:\Downloads\New folder\teset\example-app\resources\views/layouts/master.blade.php ENDPATH**/ ?>