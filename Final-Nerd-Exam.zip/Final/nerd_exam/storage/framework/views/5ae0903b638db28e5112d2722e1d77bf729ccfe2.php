

  

<?php $__env->startSection('content'); ?>
<script src="http://localhost:3000/socket.io/socket.io.js"></script>
<script>
    var socket = io('http://localhost:3000');
    // socket.on("test-channel:App\\Events\\TestEvent", function(message) {
    //     console.log('here');
    //     $('#addition').text(parseInt($('#addition').text()) + parseInt(message.data.addition));
    // });

    // socket.emit('chat message', 'test messsae');
    var room = <?php echo json_encode($room); ?>;
    console.log(room);

    socket.on('chat message', function(msg) {
        // alert(msg);

        var rooms = msg.split('|');

        $.each(rooms,function(index, value) {
            var r = value.split("^");
            //console.log(r[0]);

            if(parseInt(room.id) == parseInt(r[0])) {

                switch(parseInt(r[1])) {
                    case 1:                        
                        $("#room_status_id").css("background-color", "red");
                        $("#room_status_id").val("Occupied");
                        break;
                    case 2:
                                
                        $("#room_status_id").css("background-color", "green");
                        $("#room_status_id").val("Clean");
                        break;
                    case 3:
                        
                        $("#room_status_id").css("background-color", "brown");
                        $("#room_status_id").val("Dirty");
                        break;
                }

            }            
        });

    });
</script>
<div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Tagboard')); ?></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 margin-tb">
                            <div class="pull-right">
                                <a class="btn btn-primary" href="<?php echo e(route('tagboards.index')); ?>" enctype="multipart/form-data"> Back</a>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Room Number:</strong>
                                    <input type="text" name="room_number" value="<?php echo e($room->room_number); ?>" class="form-control" placeholder="Room number" readonly>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Room Description:</strong>
                                    <input type="text" name="room_description" class="form-control" placeholder="Room Description" value="<?php echo e($room->room_description); ?>" readonly>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Room Status:</strong>
                                    <input type="text" id="room_status_id" name="room_status_id" value="<?php echo e($room->status); ?>" class="form-control" placeholder="Room Status"  style="background-color:<?php echo e($room->color); ?>;color:white;" readonly>
                                </div>
                            </div>
           
                        </div>
           
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Downloads\New folder\teset\example-app\resources\views/tagboards/edit.blade.php ENDPATH**/ ?>