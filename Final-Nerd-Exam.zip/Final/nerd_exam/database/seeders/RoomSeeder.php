<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RoomSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("rooms")->insert([
            'room_number' => "0001",
            'room_description' => "Room 0001 description",
            'room_status_id' => 1,
            'deleted_at' => date("Y-m-d H:i:s"),
            'created_at' => date("Y-m-d H:i:s"),
            'updated_at' => date("Y-m-d H:i:s"),
           ]);
           DB::table("rooms")->insert([
            'room_number' => "0002",
            'room_description' => "Room 0002 description",
            'room_status_id' => 2,
            'deleted_at' => date("Y-m-d H:i:s"),
            'created_at' => date("Y-m-d H:i:s"),
            'updated_at' => date("Y-m-d H:i:s"),
           ]);
           DB::table("rooms")->insert([
            'room_number' => "0003",
            'room_description' => "Room 0003 description",
            'room_status_id' => 3,
            'deleted_at' => date("Y-m-d H:i:s"),
            'created_at' => date("Y-m-d H:i:s"),
            'updated_at' => date("Y-m-d H:i:s"),
           ]);
    }
}
